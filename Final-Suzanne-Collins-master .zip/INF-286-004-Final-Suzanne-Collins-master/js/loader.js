/**
 * Using a global root variable is probably bad practice, but
 * in conventional situations, you won't have to consider the
 * implications of opening the website using local files
 * (in which case the root is the root of your drive).
 */

document.addEventListener("DOMContentLoaded", function () {
    loadNav();
    loadStyles();
});

function loadNav() {
    // Dynamically load jQuery if it isn't already defined in the header
    if (typeof jQuery === "undefined") {
        let script = document.createElement("script");
        script.src = `${root}js/jquery-3.3.1.min.js`;
        script.integrity = "sha256-FgpCb/KJQlLNfOu91ta32o/NMZxltwRo8QtmkMRdAu8=";
        script.crossOrigin = "anonymous";
        script.type = "text/javascript";

        script.onload = loadNavHtml;
        document.body.appendChild(script);
    } else
        loadNavHtml();
}

function loadNavHtml() {
    $(document).ready(function () {
        // Use jQuery to replace the navigation id with the navbar html file
        $("#navigation").load(`${root}assets/header.html`, function () {
            updateHref($("#homeRef"), `${root}index.html`);
            updateHref($("#workRef"), `${root}works/works.html`);
            updateHref($("#bioRef"), `${root}biography.html`);
            updateHref($("#contactRef"), `${root}contact.html`);

            $("#menu ul li a").each(function () {
                let link = this.href;
                if (window.location.href === link)
                    $(this).closest("li").addClass("active")
            })
        });

        loadFooter();
    });
}

function loadFooter() {
    $("#foot").load(`${root}assets/footer.html`, function () {
        $("#signature").attr("src", `${root}images/Suzanne_Collins_signature.png`);
    })
}

function updateHref(ref, newUrl) {
    ref.attr("href", newUrl);
}

function loadStyles() {
    // Load fonts
    addStylesheet("https://fonts.googleapis.com/css?family=Slabo+27px|Pacifico");
    // Load default css
    addStylesheet(`${root}css/main.css`);
}

function addStylesheet(sheetLink) {
    // Add the given sheet link as a stylesheet to the head
    let fontElem = document.createElement("link");
    fontElem.href = sheetLink;
    fontElem.rel = "stylesheet";
    fontElem.type = "text/css";
    document.head.appendChild(fontElem);
}